package org.twspring.noob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoobApplication {

    public static void main(String[] args) {
        SpringApplication.run(NoobApplication.class, args);
    }

}
